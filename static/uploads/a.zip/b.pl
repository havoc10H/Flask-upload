area(R, A) :- A is pi * R * R.
