squareroot(N, Root) :-
    N >= 0,
    Root is sqrt(N).
