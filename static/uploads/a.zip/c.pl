length(X1, Y1, X2, Y2, L) :-
    L is sqrt((X2 - X1) ** 2 + (Y2 - Y1) ** 2).
