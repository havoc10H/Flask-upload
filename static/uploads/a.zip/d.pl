gradient(X1, Y1, X2, Y2, M) :-
    X2 =\= X1, % Making sure the line is not vertical
    M is (Y2 - Y1) / (X2 - X1).
