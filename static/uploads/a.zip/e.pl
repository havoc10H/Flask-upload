perpen(X11, Y11, X12, Y12, X21, Y21, X22, Y22) :-
    DX1 is X12 - X11,
    DY1 is Y12 - Y11,
    DX2 is X22 - X21,
    DY2 is Y22 - Y21,
    (DX1 * DX2) + (DY1 * DY2) =:= 0.